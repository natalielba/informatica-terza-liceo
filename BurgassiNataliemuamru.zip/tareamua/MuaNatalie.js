let Toa;
do{
    Toa = parseFloat(prompt("Ingrese tiempo inicial objeto A"));
}while(isNaN(Toa)|| Toa <0);
let Soa;
do{
    Soa = parseFloat(prompt("Ingrese posicion inicial objeto A"));
}while(isNaN(Soa));
let Voa;
do{
    Voa = parseFloat(prompt("Ingrese velocidad inicial objeto A"));
}while(isNaN(Voa));
let Aa;
do{
    Aa = parseFloat(prompt("Ingrese aceleración objeto A"));
}while(isNaN(Aa));
let Tob;
do{
    Tob = parseFloat(prompt("Ingrese tiempo inicial objeto B"));
}while(isNaN(Tob)|| Tob <0);
let Sob;
do{
    Sob = parseFloat(prompt("Ingrese posicion inicial objeto B"));
}while(isNaN(Sob));
let Vob;
do{
    Vob = parseFloat(prompt("Ingrese velocidad inicial objeto B"));
}while(isNaN(Vob));
let Ab;
do{
    Ab = parseFloat(prompt("Ingrese aceleracion objeto B"));
}while(isNaN(Ab));
let a=(Aa/2 - Ab/2);
let b= (Voa-Vob-Aa*Toa+Ab*Tob);
let c= ( Soa-Sob-Voa*Toa+Vob*Tob + (Aa/2)*Math.pow(Toa,2)-(Ab/2)*Math.pow(Tob,2))
let delta = (Math.pow(b,2)-(4*a*c));
if( a != 0)
{
    if(delta >= 0) 
    {
        let Tiempo1 = ((-b) +(Math.sqrt(delta)))/(2*a);

        let Tiempo2 = ((-b) -(Math.sqrt(delta)))/(2*a);
        let Encuentro1= (Soa-Voa*Toa+ (Aa/2)*Math.pow(Toa,2)+Tiempo1*(Voa-Aa*Toa)+(Math.pow(Tiempo1,2))*(Aa/2));
        let Encuentro2= (Soa-Voa*Toa+ (Aa/2)*Math.pow(Toa,2)+Tiempo2*(Voa-Aa*Toa)+(Math.pow(Tiempo2,2))*(Aa/2));
        console.log(Encuentro1, Tiempo1);
        console.log(Encuentro2, Tiempo2);
    }
}else
{
    let Tiempo3 = -c/b;
    let Encuentro3 = b*Tiempo3 + c;
    console.log(Encuentro3, Tiempo3);
}